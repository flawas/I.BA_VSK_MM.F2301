# DemoApp

Applikation fuer die Integration des Loggers der Gruppe g02 im Modul VSK FS23.

### Buildstatus
* [![Build Status](https://jenkins-vsk.el.eee.intern/jenkins/buildStatus/icon?job=g02-demoapp)](https://jenkins-vsk.el.eee.intern/jenkins/job/g02-demoapp/)

> Hinweis: Buildstatus nur innerhalb HSLU-Netz (oder per VPN) sichtbar!