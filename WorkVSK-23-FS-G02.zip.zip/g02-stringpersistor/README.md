# StringPersistor

Implementation des StringPersistor der Gruppe g02 im VSK FS23.

### Buildstatus
* [![Build Status](https://jenkins-vsk.el.eee.intern/jenkins/buildStatus/icon?job=g02-stringpersistor)](https://jenkins-vsk.el.eee.intern/jenkins/job/g02-stringpersistor/)

> Hinweis: Buildstatus nur innerhalb HSLU-Netz (oder per VPN) sichtbar!