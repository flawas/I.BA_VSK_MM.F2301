# Dokumentation

Repository fuer die Dokumentation der Gruppe g02 im VSK FS23.


