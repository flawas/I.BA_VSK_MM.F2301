package ch.hslu.vsk.logger.common;

import java.time.Instant;

/**
 * Implements the XML payload format.
 */
public final class PayloadFormatXMLStrategy implements PayloadFormatStrategy {

    @Override
    public String createPayload(final String level, final String source, final String message,
                                final Instant timeStamp) {
        return String.format("""
                <entry>
                    <timeStamp>%s</timeStamp>
                    <level>%s</level>
                    <source>%s</source>
                    <message>%s</message>
                </entry>
                        """, timeStamp, level, source, message);
    }

}
