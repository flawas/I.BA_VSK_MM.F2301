package ch.hslu.vsk.logger.common;

import java.time.Instant;

/**
 * Provides payload formatting strategies for log files.
 */
public interface PayloadFormatStrategy {

    /**
     * Creates the formatted string payload for the log file.
     *
     * @param level     The log message level
     * @param source    The log message source
     * @param message   The log message
     * @param timeStamp The log message timestamp
     * @return The formatted string payload
     */
    String createPayload(String level, String source, String message, Instant timeStamp);
}
